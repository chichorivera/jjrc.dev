# WP Headless Mode — Documentación Técnica

> Plugin para WordPress que convierte una instalación estándar en un CMS headless optimizado.
> Versión: **1.3.0** · Requiere PHP 8.0+ · WordPress 6.0+

---

## Índice

1. [¿Qué hace este plugin?](#qué-hace-este-plugin)
2. [Instalación](#instalación)
3. [Arquitectura](#arquitectura)
4. [Módulos](#módulos)
   - [Headless Core](#headless-core)
   - [Optimizer](#optimizer)
   - [Plugin Classifier](#plugin-classifier)
   - [API Enhancer](#api-enhancer)
   - [Admin Panel](#admin-panel)
5. [Endpoints de referencia](#endpoints-de-referencia)
   - [Audit API — headless/v1/](#audit-api)
6. [Autenticación](#autenticación)
7. [Rate Limiting](#rate-limiting)
8. [CORS](#cors)
9. [Base de datos](#base-de-datos)
10. [Configuración](#configuración)
11. [Auditoría de plugins](#auditoría-de-plugins)
12. [Optimización de autoload](#optimización-de-autoload)
13. [Limitaciones conocidas](#limitaciones-conocidas)
14. [Acerca del autor](#acerca-del-autor)

---

## ¿Qué hace este plugin?

WP Headless Mode transforma WordPress en un backend API-first desacoplando completamente el frontend del servidor. Al activarlo:

- Todas las URLs del frontend devuelven **JSON 404** en vez de HTML
- Los plugins de renderizado (Elementor, page builders, caché HTML) se **omiten en requests de API**, ahorrando memoria RAM y tiempo de ejecución
- La REST API nativa queda endurecida con CORS granular, rate limiting y headers de seguridad

---

## Instalación

1. Copia la carpeta `wp-headless-mode` a `/wp-content/plugins/`
2. Activa el plugin desde **Plugins → Plugins instalados**
3. Ve a **Headless Mode → Settings** y activa el modo headless
4. Configura los orígenes CORS permitidos con la URL de tu frontend

---

## Arquitectura

```
wp-headless-mode/
├── wp-headless-mode.php              ← Entry point, bootstrap, activation hooks
├── includes/
│   ├── class-headless-core.php       ← Bloqueo de frontend, deshabilitado de features
│   ├── class-headless-optimizer.php  ← Filtrado de plugins, heartbeat, autoload, cache cleanup
│   ├── class-plugin-classifier.php   ← Clasificación de plugins instalados
│   ├── class-api-enhancer.php        ← CORS, rate limit, headers, endpoints headless/v1/
│   └── templates/
│       └── headless-frontend.php     ← Template JSON para requests de frontend bloqueados
├── admin/
│   ├── class-headless-admin.php      ← Menú admin, AJAX handlers, badges en lista de plugins
│   └── views/
│       ├── dashboard.php             ← Vista principal con estado y métricas
│       ├── plugins.php               ← Auditoría de plugins con filtros
│       ├── settings.php              ← Formulario de configuración
│       ├── themes.php                ← Gestión del theme placeholder
│       └── about.php                 ← Acerca del autor
└── assets/
    ├── admin.css                     ← Estilos del panel
    └── admin.js                      ← Lógica del panel (jQuery)
```

### Flujo de arranque

```
plugins_loaded
  └── wp_headless_mode_init()
        ├── WP_Headless_Core::init()       → hooks de template y features
        ├── WP_Headless_Optimizer::init()  → hooks de plugins y cron
        ├── WP_Headless_API_Enhancer::init() → hooks REST
        └── WP_Headless_Admin::init()      → (solo is_admin()) menú y AJAX
```

---

## Módulos

### Headless Core

**Archivo:** `includes/class-headless-core.php`

Responsable de bloquear el frontend y eliminar ruido de WordPress.

**Qué hace cuando `headless_mode = true`:**

| Acción | Hook | Descripción |
|---|---|---|
| Bloquea frontend | `template_include` (PHP_INT_MAX) | Devuelve `headless-frontend.php` que retorna JSON 404 |
| Vacía assets del theme | `wp_enqueue_scripts` (PHP_INT_MAX) | Elimina todos los scripts y estilos del theme en frontend |
| Desactiva XML-RPC | `xmlrpc_enabled` | Stub que responde 403 JSON |
| Desactiva embeds/oEmbed | `init` | Elimina rutas, filters y head links |
| Desactiva emojis | `init` | Elimina script emoji.js y DNS prefetch de s.w.org |
| Limpia `<head>` | `init` | Elimina generator, shortlink, feed links, REST link en header |
| Añade header | `send_headers` | `X-WP-Headless: 1` en todas las respuestas |

**Respuesta a requests de frontend bloqueados:**

```json
{
  "error": "not_found",
  "message": "This WordPress installation operates in headless mode...",
  "api": {
    "rest": "https://tu-sitio.com/wp-json/wp/v2/",
    "direct": "https://tu-sitio.com/wp-json/headless-direct/v1/",
    "health": "https://tu-sitio.com/wp-json/headless/v1/health"
  }
}
```

---

### Optimizer

**Archivo:** `includes/class-headless-optimizer.php`

Optimizaciones de rendimiento para requests de API.

**Filtrado de plugins en REST:**

En cada request a la REST API, el Optimizer modifica la opción `active_plugins` en memoria para excluir plugins de frontend. Esto significa que plugins como Elementor, WP Rocket o Jetpack **nunca llegan a cargar** en requests de API, ahorrando entre 8–30 MB de RAM por request.

La lista de plugins excluidos incluye:

```
elementor, elementor-pro, beaver-builder-plugin, wp-super-cache,
w3-total-cache, wp-rocket, litespeed-cache, autoptimize,
wp-fastest-cache, jetpack
```

Los plugins marcados como `frontend` en los overrides manuales también se excluyen automáticamente.

**Otras optimizaciones:**

- Desactiva el heartbeat de WordPress en requests REST y páginas no-admin
- Elimina soporte de theme features (`automatic-feed-links`, `custom-background`, `widgets`, etc.) en contexto API
- Cron horario que limpia las tablas de caché y rate limiting

---

### Plugin Classifier

**Archivo:** `includes/class-plugin-classifier.php`

Clase estática que audita todos los plugins instalados y los clasifica en 5 categorías:

| Clasificación | Significado | Impacto headless |
|---|---|---|
| `headless-ready` | Diseñado para headless (WPGraphQL, ACF, JWT...) | Ninguno |
| `admin-only` | Solo actúa en wp-admin (Wordfence, UpdraftPlus...) | Ninguno |
| `api-aware` | Tiene REST API pero también carga assets en frontend | Bajo |
| `frontend` | Renderizador HTML, incompatible con headless | **Alto** |
| `unknown` | Sin clasificación conocida, requiere revisión | Medio |

**Prioridad de clasificación:**

1. Override manual del usuario (guardado en `wp_headless_plugin_overrides`)
2. Lista curada de 50+ plugins conocidos
3. Heurísticas de keywords en nombre y descripción del plugin

**Keywords de heurística:**

- Headless-ready: `rest api`, `graphql`, `headless`, `jwt`, `webhook`, `api endpoint`
- Admin-only: `backup`, `security`, `firewall`, `smtp`, `role`, `2fa`, `two factor`
- Frontend: `page builder`, `cache`, `widget`, `sidebar`, `gutenberg block`, `cookie`, `cdn`

---

### API Enhancer

**Archivo:** `includes/class-api-enhancer.php`

Endurece la REST API nativa de WordPress.

**CORS:**

Reemplaza el handler CORS nativo de WordPress por uno configurable. Si `cors_origins` está vacío, acepta `*`. Si tiene orígenes configurados, solo los permite explícitamente e incluye el header `Vary: Origin`.

Headers CORS enviados:
```
Access-Control-Allow-Origin: <origin>
Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS
Access-Control-Allow-Headers: Authorization, Content-Type, X-WP-Nonce, X-Headless-Key
Access-Control-Expose-Headers: X-WP-Total, X-WP-TotalPages, X-RateLimit-Remaining
Access-Control-Max-Age: 86400
```

**Headers de seguridad** (en todas las respuestas REST):
```
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
X-XSS-Protection: 1; mode=block
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: geolocation=(), camera=(), microphone=()
Cache-Control: no-store, no-cache, must-revalidate
```

**Headers de timing:**
```
X-Headless-Mode: true
X-Response-Time: 42ms
```

---

### Admin Panel

**Archivo:** `admin/class-headless-admin.php`

Panel en `wp-admin` con cinco secciones:

| Sección | URL | Descripción |
|---|---|---|
| Dashboard | `?page=wp-headless-mode` | Estado, stats de plugins, endpoints activos, optimización de DB |
| Plugins | `?page=wp-headless-plugins` | Tabla filtrable de todos los plugins con clasificación y override manual |
| Configuración | `?page=wp-headless-settings` | Todos los toggles y configuración del plugin |
| Theme | `?page=wp-headless-theme` | Instalar placeholder theme y limpiar themes innecesarios |
| Acerca de | `?page=wp-headless-about` | Información del plugin y el autor |

El panel también añade **badges de clasificación** en la lista nativa de plugins de WordPress (`Plugins → Plugins instalados`).

#### Eliminación del menú Apariencia

Cuando el modo headless está activo, el menú **Apariencia** de WordPress se elimina automáticamente del panel de administración. Esto incluye todos sus submenús: Themes, Customizer, Widgets, Menús y Theme Editor.

En instalaciones **multisite**, los superadmins conservan el acceso al menú. En single-site, todos los administradores lo pierden.

> La eliminación es dinámica: si desactivas el modo headless desde Configuración, el menú Apariencia vuelve a aparecer automáticamente en la siguiente carga del admin.

#### Gestión del theme placeholder

WordPress requiere un theme activo internamente aunque el frontend esté bloqueado. La sección **Theme** permite:

- **Instalar y activar** — copia el theme *Headless* (incluido en el plugin, 2 archivos mínimos) a `/wp-content/themes/headless/` y lo activa. Sobreescribe si ya existe.
- **Limpiar themes innecesarios** — instala y activa el placeholder primero, luego elimina permanentemente todos los demás themes. Muestra la lista antes de confirmar.

El theme placeholder consiste únicamente en `style.css` (header con metadatos) e `index.php` (archivo vacío requerido por WP), sin cargar nada en el frontend.

---

## Endpoints de referencia

### Audit API

Base: `/wp-json/headless/v1/`
Todos requieren usuario con capacidad `manage_options`.

| Método | Endpoint | Descripción |
|---|---|---|
| GET | `/plugins` | Lista de plugins clasificados. Params: `classification`, `active_only` |
| POST | `/plugins/{slug}/classify` | Sobrescribir clasificación. Body: `{ "classification": "admin-only" }` |
| GET | `/health` | Health check público. Devuelve estado de DB, versiones |
| GET | `/settings` | Configuración actual (sin exponer el secret) |
| PATCH | `/settings` | Actualizar configuración |

**Ejemplo de respuesta `/health`:**
```json
{
  "status": "ok",
  "headless": true,
  "version": "1.0.0",
  "wp_version": "6.7",
  "php_version": "8.2.0",
  "timestamp": "2026-03-30T12:00:00+00:00"
}
```

---

## Autenticación

Cuando **Requerir auth en REST API** está activo, todos los endpoints de la REST API nativa requieren autenticación. WordPress soporta nativamente **Application Passwords** (desde WP 5.6):

```bash
# Con Application Password (usuario:app-password en base64)
curl https://tu-sitio.com/wp-json/wp/v2/posts \
  -H "Authorization: Basic dXN1YXJpbzpwYXNz"
```

Genera un Application Password en **Usuarios → Tu perfil → Application Passwords**.

### Audit API

Requiere sesión de WordPress con capacidad `manage_options` (usuario admin).

---

## Rate Limiting

Aplica sobre todos los endpoints de la REST API nativa.

- **Sin autenticación:** `api_rate_limit_max` requests por hora por IP (default: 100)
- **Autenticado:** 5× el límite base

Headers de respuesta:
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 87
X-RateLimit-Window: 3600
```

Al exceder el límite:
```json
HTTP 429
{ "code": "rate_limit_exceeded", "message": "Too many requests. Please slow down." }
```

La ventana de tiempo se resetea automáticamente. El cron limpia registros vencidos cada hora.

---

## CORS

Configura los orígenes desde **Settings → Orígenes CORS permitidos**.

```
# Un origen por línea
https://mi-frontend.vercel.app
https://staging.mi-frontend.com
```

Dejar vacío = acepta cualquier origen (`*`). Cuando se configuran orígenes específicos, las requests desde orígenes no listados no recibirán los headers CORS y el browser las bloqueará.

---

## Base de datos

### `wp_headless_ratelimit`

Contador de requests por IP y endpoint.

```sql
ip            VARCHAR(45)
endpoint      VARCHAR(255)
hits          INT
window_start  DATETIME      INDEX
PRIMARY KEY (ip, endpoint)
```

La tabla se limpia automáticamente cada hora via WordPress cron.

---

## Configuración

Todas las opciones se guardan en `wp_options` bajo la clave `wp_headless_settings`.

| Clave | Tipo | Default | Descripción |
|---|---|---|---|
| `headless_mode` | bool | true | Master switch del plugin |
| `disable_themes` | bool | true | Bloquea frontend y devuelve JSON 404 |
| `disable_xmlrpc` | bool | true | Desactiva XML-RPC completamente |
| `disable_embeds` | bool | true | Elimina oEmbed y rutas de embeds |
| `disable_emojis` | bool | true | Elimina emoji.js del frontend y admin |
| `disable_wlwmanifest` | bool | true | Elimina link a Windows Live Writer |
| `disable_rsd` | bool | true | Elimina Really Simple Discovery |
| `disable_rest_open` | bool | false | Requiere auth en todos los endpoints REST |
| `api_rate_limit` | bool | true | Activa rate limiting |
| `api_rate_limit_max` | int | 100 | Requests por hora (usuarios anónimos) |
| `cors_origins` | string | '' | Orígenes permitidos, uno por línea |
| `jwt_auth` | bool | false | JWT Auth (pendiente de implementación) |
| `plugin_audit` | bool | true | Auditoría de plugins activa |

---

## Auditoría de plugins

El clasificador mantiene una lista curada de plugins conocidos. Para plugins no conocidos aplica heurísticas de texto sobre su nombre y descripción.

**Sobrescribir una clasificación:**

Desde la columna "Sobrescribir" en **Plugin Audit**, selecciona la clasificación manual. Elige "Auto" para volver a la clasificación automática.

Vía API:
```bash
curl -X POST https://tu-sitio.com/wp-json/headless/v1/plugins/elementor/classify \
  -H "Cookie: wordpress_logged_in_..." \
  -d '{"classification": "frontend"}'
```

---

## Optimización de autoload

WordPress carga **todas** las `wp_options` con `autoload=yes` en cada request, incluso cuando no se necesitan. Desde **Dashboard → Optimizar autoloaded options**, el plugin marca como `autoload=no` los siguientes patrones:

```
widget_%         → Configuraciones de widgets
sidebars_widgets → Sidebar configuration
%_transient_%    → Transients (deberían estar en object cache)
elementor%       → Opciones de Elementor
fl_%             → Opciones de Beaver Builder
theme_mods_%     → Modificaciones del theme activo
```

> **Nota:** Esta operación es irreversible automáticamente. Si luego desactivas el plugin de headless y usas el frontend de WordPress, puede ser necesario revertir este cambio manualmente.

---

## Limitaciones conocidas

### Lo que el plugin NO puede hacer

El bootstrap de WordPress siempre cargará ~200 archivos PHP y ejecutará la query de `wp_options` antes de que cualquier plugin pueda intervenir. Para reducir este overhead a nivel de servidor, considera:

- **Bedrock** (Roots.io) para estructura más limpia
- **Nginx + FastCGI cache** para cachear respuestas de API completas
- **Redis Object Cache** para cachear el bootstrap y las queries de WP

### Plugins de frontend con CPTs

Si un plugin clasificado como `frontend` (ej: Elementor) registra Custom Post Types o meta fields que necesitas en la API, **desactivarlo en REST lo romperá**. Antes de marcar un plugin como `frontend` y excluirlo, verifica qué CPTs o meta fields registra.


---

## Acerca del autor

**Javier Rivera** es Full Stack Developer con más de 25 años de experiencia construyendo soluciones digitales, habiendo evolucionado desde programador hasta liderazgo técnico y arquitectura de software.

Especializado en arquitecturas headless, e-commerce (WordPress, WooCommerce, Shopify, Magento), integraciones empresariales y desarrollo de APIs. Ha trabajado en proyectos en más de 6 países para clientes en educación, farmacéutica, retail, finanzas y gobierno.

**Stack principal:** PHP · Node.js · Python · JavaScript · Next.js · Docker · AWS

Más información en **[jjrc.dev](https://jjrc.dev/)** · [hola@jjrc.dev](mailto:hola@jjrc.dev)
