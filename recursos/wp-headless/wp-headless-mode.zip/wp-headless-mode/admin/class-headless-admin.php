<?php
defined( 'ABSPATH' ) || exit;

/**
 * WP_Headless_Admin
 *
 * Registers the admin menu pages and handles settings persistence.
 */
class WP_Headless_Admin {

    private array $settings;

    public function __construct( array $settings ) {
        $this->settings = $settings;
    }

    public function init(): void {
        add_action( 'admin_menu',             [ $this, 'register_menu' ] );
        add_action( 'admin_menu',             [ $this, 'remove_appearance_menu' ], 999 );
        add_action( 'admin_enqueue_scripts',  [ $this, 'enqueue_assets' ] );
        add_action( 'wp_ajax_headless_save_settings',   [ $this, 'ajax_save_settings' ] );
        add_action( 'wp_ajax_headless_classify_plugin', [ $this, 'ajax_classify_plugin' ] );
        add_action( 'wp_ajax_headless_optimize_options',  [ $this, 'ajax_optimize_options' ] );
        add_action( 'wp_ajax_headless_install_theme',    [ $this, 'ajax_install_headless_theme' ] );
        add_action( 'wp_ajax_headless_cleanup_themes',   [ $this, 'ajax_cleanup_themes' ] );
        add_action( 'admin_notices',          [ $this, 'admin_notices' ] );
        add_action( 'admin_head',             [ $this, 'admin_head_styles' ] );

        // Show warning in plugins list for frontend plugins
        add_filter( 'plugin_action_links', [ $this, 'plugin_action_links' ], 10, 2 );
        add_filter( 'plugin_row_meta',     [ $this, 'plugin_row_meta' ],     10, 2 );
    }

    // ── Menu ───────────────────────────────────────────────────────────────────

    public function register_menu(): void {
        add_menu_page(
            __( 'Headless Mode', 'wp-headless-mode' ),
            __( 'Headless Mode', 'wp-headless-mode' ),
            'manage_options',
            'wp-headless-mode',
            [ $this, 'page_dashboard' ],
            'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5M2 12l10 5 10-5"/></svg>' ),
            3
        );

        add_submenu_page( 'wp-headless-mode', __( 'Dashboard', 'wp-headless-mode' ),      __( 'Dashboard', 'wp-headless-mode' ),      'manage_options', 'wp-headless-mode',        [ $this, 'page_dashboard' ] );
        add_submenu_page( 'wp-headless-mode', __( 'Plugins', 'wp-headless-mode' ),       __( 'Plugins', 'wp-headless-mode' ),        'manage_options', 'wp-headless-plugins',     [ $this, 'page_plugins' ] );
        add_submenu_page( 'wp-headless-mode', __( 'Configuración', 'wp-headless-mode' ), __( 'Configuración', 'wp-headless-mode' ),  'manage_options', 'wp-headless-settings',    [ $this, 'page_settings' ] );
        add_submenu_page( 'wp-headless-mode', __( 'Theme', 'wp-headless-mode' ),         __( 'Theme', 'wp-headless-mode' ),          'manage_options', 'wp-headless-theme',       [ $this, 'page_theme' ] );
        add_submenu_page( 'wp-headless-mode', __( 'Acerca de', 'wp-headless-mode' ),    __( 'Acerca de', 'wp-headless-mode' ),      'manage_options', 'wp-headless-about',       [ $this, 'page_about' ] );

        // External link as last item — injected directly into the global $submenu array
        add_action( 'admin_menu', [ $this, 'add_website_submenu_link' ], 999 );
    }

    public function add_website_submenu_link(): void {
        global $submenu;
        $submenu['wp-headless-mode'][] = [
            'Documentación',
            'manage_options',
            'https://jjrc.dev/wp-headless/',
        ];
        $submenu['wp-headless-mode'][] = [
            'Por jjrc.dev',
            'manage_options',
            'https://jjrc.dev/',
        ];
    }

    public function admin_head_styles(): void {
        echo '<style>#adminmenu a[href="https://jjrc.dev/"]{color:#ff176b!important}#adminmenu a[href="https://jjrc.dev/"]:hover{color:#ff176b!important;opacity:.8}</style>';
    }

    // ── Assets ─────────────────────────────────────────────────────────────────

    public function enqueue_assets( string $hook ): void {
        if ( ! str_contains( $hook, 'wp-headless' ) ) return;

        wp_enqueue_style(
            'wp-headless-fonts',
            'https://fonts.googleapis.com/css2?family=Michroma&family=Inter:wght@400;500;600;700&display=swap',
            [],
            null
        );

        wp_enqueue_style(
            'wp-headless-admin',
            WP_HEADLESS_URL . 'assets/admin.css',
            [ 'wp-headless-fonts' ],
            WP_HEADLESS_VERSION
        );
        wp_enqueue_script(
            'wp-headless-admin',
            WP_HEADLESS_URL . 'assets/admin.js',
            [ 'jquery' ],
            WP_HEADLESS_VERSION,
            true
        );
        wp_localize_script( 'wp-headless-admin', 'WPHeadless', [
            'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'wp_headless_nonce' ),
            'apiUrl'   => rest_url( 'headless/v1/' ),
        ] );

        // Make the external site link in the submenu open in a new tab
        wp_add_inline_script( 'wp-headless-admin', "
            document.addEventListener('DOMContentLoaded', function() {
                ['https://jjrc.dev/wp-headless/', 'https://jjrc.dev/'].forEach(function(url) {
                    var link = document.querySelector('#adminmenu a[href=\"' + url + '\"]');
                    if (link) { link.target = '_blank'; link.rel = 'noopener'; }
                });
            });
        " );
    }

    // ── AJAX Handlers ──────────────────────────────────────────────────────────

    public function ajax_save_settings(): void {
        check_ajax_referer( 'wp_headless_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

        $current  = get_option( WP_HEADLESS_OPTIONS_KEY, [] );
        $booleans = [
            'headless_mode', 'disable_themes', 'disable_xmlrpc', 'disable_embeds',
            'disable_emojis', 'disable_wlwmanifest', 'disable_rsd',
            'disable_rest_open', 'api_rate_limit', 'jwt_auth', 'plugin_audit',
        ];
        foreach ( $booleans as $key ) {
            $current[ $key ] = ! empty( $_POST[ $key ] );
        }

        $current['api_rate_limit_max'] = max( 10, min( 10000, (int) ( $_POST['api_rate_limit_max'] ?? 100 ) ) );
        $current['cors_origins']       = sanitize_textarea_field( $_POST['cors_origins'] ?? '' );

        update_option( WP_HEADLESS_OPTIONS_KEY, $current );

        // Trigger autoload optimization if requested
        if ( ! empty( $_POST['optimize_autoload'] ) ) {
            do_action( 'wp_headless_optimize_autoload' );
        }

        wp_send_json_success( [ 'message' => 'Settings saved.' ] );
    }

    public function ajax_classify_plugin(): void {
        check_ajax_referer( 'wp_headless_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

        $slug           = sanitize_key( $_POST['slug'] ?? '' );
        $classification = sanitize_key( $_POST['classification'] ?? '' );

        if ( $classification === 'auto' ) {
            WP_Headless_Plugin_Classifier::remove_override( $slug );
        } else {
            WP_Headless_Plugin_Classifier::set_override( $slug, $classification );
        }

        wp_send_json_success();
    }

    public function ajax_optimize_options(): void {
        check_ajax_referer( 'wp_headless_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );
        do_action( 'wp_headless_optimize_autoload' );
        wp_send_json_success( [ 'message' => 'Autoloaded options optimized.' ] );
    }

    // ── Admin Notices ──────────────────────────────────────────────────────────

    public function admin_notices(): void {
        if ( empty( $this->settings['headless_mode'] ) ) {
            echo '<div class="notice notice-warning"><p><strong>WP Headless Mode:</strong> El modo headless está <strong>desactivado</strong>. <a href="' . esc_url( admin_url( 'admin.php?page=wp-headless-settings' ) ) . '">Activar →</a></p></div>';
        }
    }

    public function plugin_action_links( array $actions, string $plugin_file ): array {
        $slug      = explode( '/', $plugin_file )[0];
        $overrides = (array) get_option( 'wp_headless_plugin_overrides', [] );
        $class     = $overrides[ $slug ] ?? null;

        if ( ! $class ) {
            $plugins = WP_Headless_Plugin_Classifier::classify_all();
            $class   = $plugins[ $slug ]['classification'] ?? 'unknown';
        }

        if ( $class === 'frontend' ) {
            $actions['headless_warn'] = '<span style="color:#d63638;font-weight:600">⚠ No headless</span>';
        }
        return $actions;
    }

    public function plugin_row_meta( array $meta, string $plugin_file ): array {
        // Add website link only on our own plugin row
        if ( plugin_basename( WP_HEADLESS_DIR . 'wp-headless-mode.php' ) === $plugin_file ) {
            $meta[] = '<a href="https://jjrc.dev/wp-headless/" target="_blank" rel="noopener">Sitio web</a>';
        }

        $slug    = explode( '/', $plugin_file )[0];
        $plugins = WP_Headless_Plugin_Classifier::classify_all();
        $info    = $plugins[ $slug ] ?? null;
        if ( $info ) {
            $badges = [
                'headless-ready' => [ '🟢 Headless Ready', '#00a32a' ],
                'admin-only'     => [ '🔵 Solo Admin',     '#0073aa' ],
                'api-aware'      => [ '🟡 API Aware',      '#dba617' ],
                'frontend'       => [ '🔴 Frontend Only',  '#d63638' ],
                'unknown'        => [ '⚪ Sin clasificar',  '#888'    ],
            ];
            [ $label, $color ] = $badges[ $info['classification'] ] ?? $badges['unknown'];
            $meta[] = "<span style='color:$color;font-weight:600'>$label</span>";
        }
        return $meta;
    }

    // ── Page: Dashboard ────────────────────────────────────────────────────────

    public function page_dashboard(): void {
        $plugins    = WP_Headless_Plugin_Classifier::classify_all();
        $active     = array_filter( $plugins, fn( $p ) => $p['active'] );
        $counts     = array_count_values( array_column( $active, 'classification' ) );
        $mode       = ! empty( $this->settings['headless_mode'] );
        $plugin_url = 'https://jjrc.dev/wp-headless/';
        require WP_HEADLESS_DIR . 'admin/views/dashboard.php';
    }

    // ── Page: Plugin Audit ─────────────────────────────────────────────────────

    public function page_plugins(): void {
        $plugins    = WP_Headless_Plugin_Classifier::classify_all();
        $plugin_url = 'https://jjrc.dev/wp-headless/';
        require WP_HEADLESS_DIR . 'admin/views/plugins.php';
    }

    // ── Page: Settings ─────────────────────────────────────────────────────────

    public function page_settings(): void {
        $s          = $this->settings;
        $plugin_url = 'https://jjrc.dev/wp-headless/';
        require WP_HEADLESS_DIR . 'admin/views/settings.php';
    }

    // ── Page: Theme ─────────────────────────────────────────────────────────────

    public function page_theme(): void {
        $plugin_url = 'https://jjrc.dev/wp-headless/';
        require WP_HEADLESS_DIR . 'admin/views/themes.php';
    }

    public function page_about(): void {
        $plugin_url = 'https://jjrc.dev/wp-headless/';
        require WP_HEADLESS_DIR . 'admin/views/about.php';
    }

    // ── Theme Management ───────────────────────────────────────────────────────

    public function ajax_install_headless_theme(): void {
        check_ajax_referer( 'wp_headless_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

        $result = $this->install_headless_theme();

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( [ 'message' => $result->get_error_message() ] );
        }

        wp_send_json_success( [ 'message' => 'Theme Headless instalado y activado.' ] );
    }

    public function ajax_cleanup_themes(): void {
        check_ajax_referer( 'wp_headless_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

        $result = $this->install_headless_theme();

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( [ 'message' => $result->get_error_message() ] );
            return;
        }

        $deleted = $this->delete_other_themes();

        wp_send_json_success( [
            'message' => sprintf(
                'Theme Headless activado. %d theme(s) eliminado(s).',
                $deleted
            ),
        ] );
    }

    /**
     * Copies the bundled minimal theme into wp-content/themes/headless/,
     * overwrites if it already exists, then activates it.
     */
    private function install_headless_theme(): bool|WP_Error {
        $theme_dir  = get_theme_root() . '/headless';
        $source_dir = WP_HEADLESS_DIR . 'theme/';

        if ( ! is_dir( $theme_dir ) && ! wp_mkdir_p( $theme_dir ) ) {
            return new WP_Error( 'mkdir_failed', 'No se pudo crear el directorio del theme.' );
        }

        foreach ( [ 'style.css', 'index.php' ] as $file ) {
            if ( ! copy( $source_dir . $file, $theme_dir . '/' . $file ) ) {
                return new WP_Error( 'copy_failed', "No se pudo copiar $file al directorio de themes." );
            }
        }

        wp_clean_themes_cache();
        switch_theme( 'headless' );

        return true;
    }

    /**
     * Deletes all installed themes except the headless placeholder.
     * Returns the number of themes deleted.
     */
    private function delete_other_themes(): int {
        require_once ABSPATH . 'wp-admin/includes/theme.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';

        WP_Filesystem();

        $deleted = 0;
        foreach ( wp_get_themes() as $slug => $theme ) {
            if ( $slug === 'headless' ) {
                continue;
            }
            if ( delete_theme( $slug ) ) {
                $deleted++;
            }
        }

        return $deleted;
    }

    // ── Appearance Menu ────────────────────────────────────────────────────────

    /**
     * Removes the Appearance menu when headless mode is active.
     * Superadmins on multisite keep access; single-site admins lose it
     * since themes, customizer, widgets and menus are irrelevant in headless.
     */
    public function remove_appearance_menu(): void {
        if ( empty( $this->settings['headless_mode'] ) ) {
            return;
        }

        // On multisite, only superadmins can still see it.
        if ( is_multisite() && is_super_admin() ) {
            return;
        }

        remove_menu_page( 'themes.php' );

        // Also remove submenu items other plugins may have added under Appearance.
        remove_submenu_page( 'themes.php', 'themes.php' );
        remove_submenu_page( 'themes.php', 'theme-install.php' );
        remove_submenu_page( 'themes.php', 'customize.php' );
        remove_submenu_page( 'themes.php', 'custom-header' );
        remove_submenu_page( 'themes.php', 'custom-background' );
        remove_submenu_page( 'themes.php', 'nav-menus.php' );
        remove_submenu_page( 'themes.php', 'theme-editor.php' );
        remove_submenu_page( 'themes.php', 'widgets.php' );
    }
}
