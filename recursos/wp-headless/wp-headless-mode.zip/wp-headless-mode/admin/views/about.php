<?php defined( 'ABSPATH' ) || exit; ?>
<div class="wrap wph-wrap">
    <div class="wph-page-header">
        <h1>Acerca de</h1>
        <a href="<?= esc_url( $plugin_url ) ?>" target="_blank" rel="noopener" class="wph-site-link">jjrc.dev/wp-headless</a>
    </div>

    <div class="wph-grid-2">

        <div class="wph-panel">
            <h2>El Plugin</h2>
            <p><strong>WP Headless Mode</strong> nació de la necesidad práctica de usar WordPress como CMS headless sin el overhead del frontend tradicional. Convierte una instalación estándar en un backend API-first optimizado: bloquea el renderizado de themes, expone endpoints MySQL directos y clasifica los plugins según su compatibilidad headless.</p>
            <p style="margin-top:12px">Desarrollado con PHP 8.0+, compatible con WordPress 6.0+ y diseñado para integrarse con cualquier frontend moderno (Next.js, Nuxt, Astro, etc.).</p>
        </div>

        <div class="wph-panel">
            <h2>El Autor</h2>
            <p><strong>Javier Rivera</strong> es Full Stack Developer con más de 25 años de experiencia en soluciones digitales, desde desarrollo web en los 2000s hasta arquitectura de software empresarial y desarrollo asistido por IA.</p>
            <p style="margin-top:12px">Especializado en arquitecturas headless, e-commerce (WordPress, WooCommerce, Shopify), integraciones de sistemas y APIs. Ha trabajado en proyectos en más de 6 países para clientes en educación, retail, finanzas y gobierno.</p>
            <p style="margin-top:16px">
                <a href="https://jjrc.dev/" target="_blank" rel="noopener" class="button button-secondary">jjrc.dev</a>
                <a href="mailto:hola@jjrc.dev" class="button button-secondary" style="margin-left:8px">hola@jjrc.dev</a>
            </p>
        </div>

    </div>
</div>
