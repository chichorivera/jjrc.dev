<?php defined( 'ABSPATH' ) || exit;

$active_theme  = wp_get_theme();
$is_headless   = ( $active_theme->get_stylesheet() === 'headless' );
$all_themes    = wp_get_themes();
$other_count   = count( array_filter( array_keys( $all_themes ), fn( $s ) => $s !== 'headless' ) );
?>
<div class="wrap wph-wrap">
    <div class="wph-page-header">
        <h1>Theme Headless</h1>
        <a href="<?= esc_url( $plugin_url ) ?>" target="_blank" rel="noopener" class="wph-site-link">jjrc.dev/wp-headless</a>
    </div>
    <p>WordPress requiere un theme activo internamente. El <strong>theme Headless</strong> es un placeholder mínimo (2 archivos) que satisface esa dependencia sin cargar nada en el frontend.</p>

    <!-- Status -->
    <div class="wph-status-bar <?= $is_headless ? 'wph-active' : 'wph-inactive' ?>">
        <span class="wph-dot"></span>
        Theme activo: <strong><?= esc_html( $active_theme->get( 'Name' ) ) ?></strong>
        <?= $is_headless ? '— <strong>Headless placeholder activo ✓</strong>' : '— <span style="color:#fff">⚠ No es el theme Headless</span>' ?>
    </div>

    <div class="wph-grid-2" style="margin-top:24px">

        <!-- Instalar -->
        <div class="wph-panel">
            <h2>Instalar theme Headless</h2>
            <p>Copia el theme placeholder incluido en el plugin al directorio <code>/wp-content/themes/headless/</code> y lo activa. Si ya existe, lo sobreescribe.</p>
            <p>El theme consiste en dos archivos mínimos:</p>
            <ul style="margin:10px 0 16px 18px;font-size:13px;color:#ccc">
                <li><code>style.css</code> — header con nombre y metadatos</li>
                <li><code>index.php</code> — archivo vacío requerido por WP</li>
            </ul>
            <button type="button" class="button button-primary" id="wph-install-theme">
                Instalar y activar
            </button>
            <span id="wph-install-theme-result" style="margin-left:10px;"></span>
        </div>

        <!-- Limpiar -->
        <div class="wph-panel wph-panel-danger">
            <h2>Limpiar themes innecesarios</h2>
            <p>Instala y activa el theme Headless, luego <strong>elimina permanentemente</strong> todos los demás themes instalados.</p>
            <?php if ( $other_count > 0 ) : ?>
                <p style="font-size:13px;color:#ccc">Themes que se eliminarán: <strong><?= $other_count ?></strong></p>
                <ul style="margin:8px 0 16px 18px;font-size:12px;color:#aaa">
                <?php foreach ( $all_themes as $slug => $theme ) : ?>
                    <?php if ( $slug === 'headless' ) continue; ?>
                    <li><?= esc_html( $theme->get( 'Name' ) ) ?> <span style="color:#666">(<?= esc_html( $slug ) ?>)</span></li>
                <?php endforeach; ?>
                </ul>
            <?php else : ?>
                <p style="font-size:13px;color:#00a32a">✓ No hay otros themes instalados.</p>
            <?php endif; ?>
            <button type="button" class="button" id="wph-cleanup-themes"
                style="border-color:#d63638;color:#d63638"
                <?= $other_count === 0 ? 'disabled' : '' ?>>
                Eliminar otros themes (<?= $other_count ?>)
            </button>
            <span id="wph-cleanup-themes-result" style="margin-left:10px;"></span>
        </div>

    </div>
</div>
