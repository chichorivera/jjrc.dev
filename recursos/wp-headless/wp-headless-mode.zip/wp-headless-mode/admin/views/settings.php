<?php defined( 'ABSPATH' ) || exit; ?>
<div class="wrap wph-wrap">
    <div class="wph-page-header">
        <h1>Configuración — WP Headless Mode</h1>
        <a href="<?= esc_url( $plugin_url ) ?>" target="_blank" rel="noopener" class="wph-site-link">jjrc.dev/wp-headless</a>
    </div>

    <form id="wph-settings-form">
        <?php wp_nonce_field( 'wp_headless_nonce', 'nonce' ); ?>

        <div class="wph-grid-2">

            <!-- Core Headless -->
            <div class="wph-panel">
                <h2>Modo Headless</h2>
                <table class="form-table wph-form-table">
                    <tr>
                        <th>Activar modo headless</th>
                        <td>
                            <label class="wph-toggle">
                                <input type="checkbox" name="headless_mode" value="1" <?= checked( $s['headless_mode'] ?? false, true, false ) ?>>
                                <span class="wph-toggle-slider"></span>
                            </label>
                            <p class="description">Activa todas las optimizaciones headless.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Bloquear themes en frontend</th>
                        <td>
                            <label class="wph-toggle">
                                <input type="checkbox" name="disable_themes" value="1" <?= checked( $s['disable_themes'] ?? false, true, false ) ?>>
                                <span class="wph-toggle-slider"></span>
                            </label>
                            <p class="description">Las URLs del frontend devolverán JSON 404 en vez de HTML.</p>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- Feature Disablers -->
            <div class="wph-panel">
                <h2>Funciones a Deshabilitar</h2>
                <table class="form-table wph-form-table">
                    <?php
                    $toggles = [
                        'disable_xmlrpc'      => [ 'XML-RPC',          'Protocolo legacy. Sin uso en headless.' ],
                        'disable_embeds'       => [ 'oEmbed / Embeds',  'iframes de embeds. Innecesario en headless.' ],
                        'disable_emojis'       => [ 'Script de Emojis', 'Elimina emoji.js del frontend y admin.' ],
                        'disable_wlwmanifest'  => [ 'wlwmanifest',      'Link a Windows Live Writer. Obsoleto.' ],
                        'disable_rsd'          => [ 'RSD Link',         'Really Simple Discovery. No necesario.' ],
                    ];
                    foreach ( $toggles as $key => [ $label, $desc ] ) :
                    ?>
                    <tr>
                        <th><?= esc_html( $label ) ?></th>
                        <td>
                            <label class="wph-toggle">
                                <input type="checkbox" name="<?= esc_attr( $key ) ?>" value="1" <?= checked( $s[ $key ] ?? false, true, false ) ?>>
                                <span class="wph-toggle-slider"></span>
                            </label>
                            <p class="description"><?= esc_html( $desc ) ?></p>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </table>
            </div>

            <!-- REST API Security -->
            <div class="wph-panel">
                <h2>Seguridad REST API</h2>
                <table class="form-table wph-form-table">
                    <tr>
                        <th>Requerir auth en REST API</th>
                        <td>
                            <label class="wph-toggle">
                                <input type="checkbox" name="disable_rest_open" value="1" <?= checked( $s['disable_rest_open'] ?? false, true, false ) ?>>
                                <span class="wph-toggle-slider"></span>
                            </label>
                            <p class="description">⚠️ Todos los endpoints REST requerirán autenticación. Asegúrate de tener Application Passwords o JWT configurado.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Rate Limiting</th>
                        <td>
                            <label class="wph-toggle">
                                <input type="checkbox" name="api_rate_limit" value="1" <?= checked( $s['api_rate_limit'] ?? false, true, false ) ?>>
                                <span class="wph-toggle-slider"></span>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th>Requests por hora (sin auth)</th>
                        <td>
                            <input type="number" name="api_rate_limit_max" value="<?= esc_attr( $s['api_rate_limit_max'] ?? 100 ) ?>" min="10" max="10000" class="small-text">
                            <p class="description">Usuarios autenticados obtienen 5x este valor.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Orígenes CORS permitidos</th>
                        <td>
                            <textarea name="cors_origins" rows="4" class="large-text"><?= esc_textarea( $s['cors_origins'] ?? '' ) ?></textarea>
                            <p class="description">Un origen por línea. Ej: <code>https://mi-frontend.com</code><br>Vacío = acepta todos (<code>*</code>).</p>
                        </td>
                    </tr>
                </table>
            </div>

        </div>

        <div class="wph-panel">
            <h2>Optimización de Base de Datos</h2>
            <p>Marca automáticamente como <code>autoload=no</code> las opciones de plugins de widgets, sidebars, temas y caché que WordPress no necesita cargar en cada request de API.</p>
            <label>
                <input type="checkbox" name="optimize_autoload" value="1">
                Ejecutar optimización de autoload al guardar
            </label>
        </div>

        <p class="submit">
            <button type="submit" class="button button-primary button-large" id="wph-save-btn">
                Guardar configuración
            </button>
            <span id="wph-save-result" style="margin-left:15px;"></span>
        </p>
    </form>

</div>
