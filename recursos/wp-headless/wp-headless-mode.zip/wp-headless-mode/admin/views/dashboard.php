<?php defined( 'ABSPATH' ) || exit; ?>
<div class="wrap wph-wrap">
    <div class="wph-page-header">
        <h1>WP Headless Mode — Dashboard</h1>
        <a href="<?= esc_url( $plugin_url ) ?>" target="_blank" rel="noopener" class="wph-site-link">jjrc.dev/wp-headless</a>
    </div>

    <div class="wph-status-bar <?= $mode ? 'wph-active' : 'wph-inactive' ?>">
        <span class="wph-dot"></span>
        <?= $mode ? 'Modo Headless <strong>ACTIVO</strong>' : 'Modo Headless <strong>INACTIVO</strong>' ?>
        <a href="<?= esc_url( admin_url( 'admin.php?page=wp-headless-settings' ) ) ?>" class="wph-btn-sm">Configurar</a>
    </div>

    <!-- Stats Cards -->
    <h2 class="wph-section-title">Auditoría de Plugins</h2>
    <div class="wph-grid-4">
        <div class="wph-card wph-card-green">
            <div class="wph-card-num"><?= $counts['headless-ready'] ?? 0 ?></div>
            <div class="wph-card-label">Headless Ready</div>
        </div>
        <div class="wph-card wph-card-blue">
            <div class="wph-card-num"><?= $counts['admin-only'] ?? 0 ?></div>
            <div class="wph-card-label">Solo Admin</div>
        </div>
        <div class="wph-card wph-card-yellow">
            <div class="wph-card-num"><?= ( $counts['api-aware'] ?? 0 ) + ( $counts['unknown'] ?? 0 ) ?></div>
            <div class="wph-card-label">Requieren Revisión</div>
        </div>
        <div class="wph-card wph-card-red">
            <div class="wph-card-num"><?= $counts['frontend'] ?? 0 ?></div>
            <div class="wph-card-label">No Headless</div>
        </div>
    </div>

    <!-- Quick actions -->
    <div class="wph-grid-2">
        <div class="wph-panel">
            <h2>API Endpoints</h2>
            <table class="wph-table">
                <tr>
                    <td>REST API nativa</td>
                    <td><code><?= esc_html( rest_url( 'wp/v2/' ) ) ?></code></td>
                    <td><span class="wph-badge wph-badge-green">Activa</span></td>
                </tr>
                <tr>
                    <td>Headless Audit API</td>
                    <td><code><?= esc_html( rest_url( 'headless/v1/' ) ) ?></code></td>
                    <td><span class="wph-badge wph-badge-green">Activa</span></td>
                </tr>
                <tr>
                    <td>Health Check</td>
                    <td><code><?= esc_html( rest_url( 'headless/v1/health' ) ) ?></code></td>
                    <td><a href="<?= esc_url( rest_url( 'headless/v1/health' ) ) ?>" target="_blank" class="wph-badge wph-badge-blue">Abrir →</a></td>
                </tr>
            </table>
        </div>
        <div class="wph-panel">
            <h2>Optimizaciones Activas</h2>
            <?php
            $optimizations = [
                'disable_themes'      => 'Theme frontend bloqueado',
                'disable_xmlrpc'      => 'XML-RPC deshabilitado',
                'disable_embeds'      => 'oEmbed/Embeds eliminado',
                'disable_emojis'      => 'Emojis JS deshabilitado',
                'disable_wlwmanifest' => 'wlwmanifest eliminado',
                'disable_rsd'         => 'RSD link eliminado',
                'api_rate_limit'      => 'Rate limiting API',
            ];
            ?>
            <ul class="wph-checklist">
            <?php foreach ( $optimizations as $key => $label ) : ?>
                <li class="<?= ! empty( $this->settings[ $key ] ) ? 'wph-check-on' : 'wph-check-off' ?>">
                    <?= ! empty( $this->settings[ $key ] ) ? '✅' : '⬜' ?> <?= esc_html( $label ) ?>
                </li>
            <?php endforeach; ?>
            </ul>
        </div>
    </div>

    <!-- Frontend plugins warning -->
    <?php
    $frontend_active = array_filter( $active, fn( $p ) => $p['classification'] === 'frontend' );
    if ( $frontend_active ) :
    ?>
    <div class="wph-panel wph-panel-danger">
        <h2>Plugins de Frontend Activos (<?= count( $frontend_active ) ?>)</h2>
        <p>Los siguientes plugins están pensados para renderizado en el servidor y no son compatibles con arquitectura headless. Considera desactivarlos o reemplazarlos.</p>
        <div class="wph-plugin-list">
        <?php foreach ( $frontend_active as $p ) : ?>
            <div class="wph-plugin-item wph-plugin-danger">
                <strong><?= esc_html( $p['name'] ) ?></strong>
                <span><?= esc_html( $p['recommendation'] ) ?></span>
                <a href="<?= esc_url( admin_url( 'plugins.php' ) ) ?>">Ver plugins</a>
            </div>
        <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <div class="wph-panel">
        <h2>Optimización de Base de Datos</h2>
        <p>WordPress carga todas las opciones con <code>autoload=yes</code> en cada request. Puedes marcar las no críticas como <code>autoload=no</code> para reducir el overhead.</p>
        <button class="button button-secondary" id="wph-optimize-options">Optimizar autoloaded options</button>
        <span id="wph-optimize-result" style="margin-left:10px;"></span>
    </div>
</div>
