<?php defined( 'ABSPATH' ) || exit;
$classifications = [
    'headless-ready' => [ 'label' => '🟢 Headless Ready', 'class' => 'wph-badge-green'  ],
    'admin-only'     => [ 'label' => '🔵 Solo Admin',     'class' => 'wph-badge-blue'   ],
    'api-aware'      => [ 'label' => '🟡 API Aware',      'class' => 'wph-badge-yellow' ],
    'frontend'       => [ 'label' => '🔴 Frontend Only',  'class' => 'wph-badge-red'    ],
    'unknown'        => [ 'label' => '⚪ Sin clasificar',  'class' => 'wph-badge-grey'   ],
];
?>
<div class="wrap wph-wrap">
    <div class="wph-page-header">
        <h1>Auditoría de Plugins</h1>
        <a href="<?= esc_url( $plugin_url ) ?>" target="_blank" rel="noopener" class="wph-site-link">jjrc.dev/wp-headless</a>
    </div>
    <p>Cada plugin instalado ha sido clasificado según su compatibilidad con una arquitectura headless. Puedes sobrescribir la clasificación automática manualmente.</p>

    <!-- Filter bar -->
    <div class="wph-filter-bar">
        <button class="wph-filter-btn wph-filter-active" data-filter="all">Todos (<?= count( $plugins ) ?>)</button>
        <?php foreach ( $classifications as $key => $info ) :
            $count = count( array_filter( $plugins, fn( $p ) => $p['classification'] === $key ) );
            if ( ! $count ) continue;
        ?>
            <button class="wph-filter-btn" data-filter="<?= esc_attr( $key ) ?>">
                <?= esc_html( $info['label'] ) ?> (<?= $count ?>)
            </button>
        <?php endforeach; ?>
        <label style="margin-left:auto">
            <input type="checkbox" id="wph-active-only"> Solo activos
        </label>
    </div>

    <!-- Plugin Table -->
    <table class="wph-audit-table widefat">
        <thead>
            <tr>
                <th>Plugin</th>
                <th>Versión</th>
                <th>Estado</th>
                <th>Clasificación</th>
                <th>Impacto Headless</th>
                <th>Recomendación</th>
                <th>Sobrescribir</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ( $plugins as $p ) :
            $cls = $classifications[ $p['classification'] ] ?? $classifications['unknown'];
        ?>
            <tr class="wph-plugin-row"
                data-classification="<?= esc_attr( $p['classification'] ) ?>"
                data-active="<?= $p['active'] ? '1' : '0' ?>">
                <td>
                    <strong><?= esc_html( $p['name'] ) ?></strong><br>
                    <small style="color:#888"><?= esc_html( $p['slug'] ) ?></small>
                    <?php if ( $p['manual_override'] ) : ?>
                        <br><small style="color:#7f54b3">✏ Clasificación manual</small>
                    <?php endif; ?>
                </td>
                <td><?= esc_html( $p['version'] ) ?></td>
                <td>
                    <?php if ( $p['active'] ) : ?>
                        <span class="wph-badge wph-badge-green">Activo</span>
                    <?php else : ?>
                        <span class="wph-badge wph-badge-grey">Inactivo</span>
                    <?php endif; ?>
                </td>
                <td>
                    <span class="wph-badge <?= esc_attr( $cls['class'] ) ?>">
                        <?= esc_html( $cls['label'] ) ?>
                    </span>
                </td>
                <td>
                    <?php
                    $impact_map = [
                        'none'    => '<span style="color:#00a32a">●</span> Ninguno',
                        'low'     => '<span style="color:#dba617">●</span> Bajo',
                        'medium'  => '<span style="color:#d97706">●</span> Medio',
                        'high'    => '<span style="color:#d63638">●</span> Alto',
                        'unknown' => '<span style="color:#888">●</span> Desconocido',
                    ];
                    echo $impact_map[ $p['headless_impact'] ] ?? $impact_map['unknown'];
                    ?>
                </td>
                <td style="max-width:280px;font-size:12px"><?= esc_html( $p['recommendation'] ) ?></td>
                <td>
                    <select class="wph-classify-select" data-slug="<?= esc_attr( $p['slug'] ) ?>">
                        <option value="auto" <?= ! $p['manual_override'] ? 'selected' : '' ?>>Auto</option>
                        <?php foreach ( $classifications as $key => $info ) : ?>
                            <option value="<?= esc_attr( $key ) ?>" <?= $p['manual_override'] === $key ? 'selected' : '' ?>>
                                <?= esc_html( $info['label'] ) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
