/* WP Headless Mode — Admin JS */
(function ($) {
    'use strict';

    // ── Settings Form ──────────────────────────────────────────────────────────
    $('#wph-settings-form').on('submit', function (e) {
        e.preventDefault();
        const btn    = $('#wph-save-btn');
        const result = $('#wph-save-result');
        btn.text('Guardando...').prop('disabled', true);

        const data = $(this).serializeArray().reduce((obj, item) => {
            obj[item.name] = item.value;
            return obj;
        }, { action: 'headless_save_settings' });

        // Booleans: include unchecked as 0
        ['headless_mode','disable_themes','disable_xmlrpc','disable_embeds',
         'disable_emojis','disable_wlwmanifest','disable_rsd','disable_rest_open',
         'api_rate_limit','jwt_auth','plugin_audit','optimize_autoload'].forEach(k => {
            if (!(k in data)) data[k] = 0;
        });

        $.post(WPHeadless.ajaxUrl, data)
            .done(res => {
                result.html('<span style="color:#00a32a">✅ ' + (res.data?.message || 'Guardado') + '</span>');
                setTimeout(() => result.html(''), 3000);
            })
            .fail(() => result.html('<span style="color:#d63638">❌ Error al guardar</span>'))
            .always(() => btn.text('💾 Guardar configuración').prop('disabled', false));
    });

    // ── Plugin Classification ──────────────────────────────────────────────────
    $(document).on('change', '.wph-classify-select', function () {
        const slug           = $(this).data('slug');
        const classification = $(this).val();
        const $row           = $(this).closest('tr');

        $.post(WPHeadless.ajaxUrl, {
            action:         'headless_classify_plugin',
            nonce:          WPHeadless.nonce,
            slug,
            classification
        }).done(() => {
            $row.addClass('wph-highlight');
            setTimeout(() => $row.removeClass('wph-highlight'), 800);
        });
    });

    // ── Plugin Audit Filters ───────────────────────────────────────────────────
    let activeFilter = 'all';
    let activeOnly   = false;

    function applyFilters() {
        $('.wph-plugin-row').each(function () {
            const cls    = $(this).data('classification');
            const active = $(this).data('active') === 1 || $(this).data('active') === '1';
            let show = true;
            if (activeFilter !== 'all' && cls !== activeFilter) show = false;
            if (activeOnly && !active) show = false;
            $(this).toggle(show);
        });
    }

    $(document).on('click', '.wph-filter-btn', function () {
        $('.wph-filter-btn').removeClass('wph-filter-active');
        $(this).addClass('wph-filter-active');
        activeFilter = $(this).data('filter');
        applyFilters();
    });

    $('#wph-active-only').on('change', function () {
        activeOnly = this.checked;
        applyFilters();
    });

    // ── Optimize Options ───────────────────────────────────────────────────────
    $('#wph-optimize-options').on('click', function () {
        const $btn    = $(this);
        const $result = $('#wph-optimize-result');
        $btn.prop('disabled', true).text('Optimizando...');
        $.post(WPHeadless.ajaxUrl, {
            action: 'headless_optimize_options',
            nonce:  WPHeadless.nonce
        }).done(res => {
            $result.html('<span style="color:#00a32a">✅ ' + (res.data?.message || 'Optimizado') + '</span>');
        }).fail(() => {
            $result.html('<span style="color:#d63638">❌ Error</span>');
        }).always(() => {
            $btn.prop('disabled', false).text('Optimizar autoloaded options');
            setTimeout(() => $result.html(''), 4000);
        });
    });

    // ── Theme Management ──────────────────────────────────────────────────────
    function themeAction( action, btnId, resultId, confirmMsg ) {
        const $btn    = $( btnId );
        const $result = $( resultId );

        if ( confirmMsg && ! confirm( confirmMsg ) ) return;

        $btn.prop( 'disabled', true ).text( 'Procesando...' );
        $result.html( '' );

        $.post( WPHeadless.ajaxUrl, { action, nonce: WPHeadless.nonce } )
            .done( res => {
                if ( res.success ) {
                    $result.html( '<span style="color:#00a32a">✅ ' + res.data.message + '</span>' );
                    setTimeout( () => location.reload(), 1500 );
                } else {
                    $result.html( '<span style="color:#d63638">❌ ' + ( res.data?.message || 'Error' ) + '</span>' );
                    $btn.prop( 'disabled', false );
                }
            } )
            .fail( () => {
                $result.html( '<span style="color:#d63638">❌ Error de conexión</span>' );
                $btn.prop( 'disabled', false );
            } );
    }

    $( '#wph-install-theme' ).on( 'click', function () {
        themeAction(
            'headless_install_theme',
            '#wph-install-theme',
            '#wph-install-theme-result',
            null
        );
    } );

    $( '#wph-cleanup-themes' ).on( 'click', function () {
        themeAction(
            'headless_cleanup_themes',
            '#wph-cleanup-themes',
            '#wph-cleanup-themes-result',
            '⚠️ Esto eliminará PERMANENTEMENTE todos los themes excepto el Headless.\n\n¿Estás seguro?'
        );
    } );

    // ── Row highlight animation ────────────────────────────────────────────────
    const style = document.createElement('style');
    style.textContent = `
        .wph-highlight { background: #fef9e7 !important; transition: background .8s; }
    `;
    document.head.appendChild(style);

})(jQuery);
