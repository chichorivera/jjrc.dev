<?php
/**
 * Headless frontend template.
 * Replaces all theme templates for non-admin, non-API requests.
 * Returns a JSON message indicating the site is headless-only.
 */
defined( 'ABSPATH' ) || exit;

status_header( 404 );
header( 'Content-Type: application/json; charset=utf-8' );
header( 'X-WP-Headless: true' );
header( 'Cache-Control: no-store' );

echo wp_json_encode( [
    'error'   => 'not_found',
    'message' => 'This WordPress installation operates in headless mode. The frontend is served by a separate application. Access content via the REST API.',
    'api'     => [
        'rest'   => rest_url( 'wp/v2/' ),
        'direct' => rest_url( 'headless-direct/v1/' ),
        'health' => rest_url( 'headless/v1/health' ),
    ],
    'docs'    => admin_url( 'admin.php?page=wp-headless-direct-api' ),
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
exit;
