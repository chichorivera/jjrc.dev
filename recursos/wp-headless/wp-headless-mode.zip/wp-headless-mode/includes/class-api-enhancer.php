<?php
defined( 'ABSPATH' ) || exit;

/**
 * WP_Headless_API_Enhancer
 *
 * Hardens and extends the native WordPress REST API:
 * - CORS configuration
 * - Rate limiting per IP + endpoint
 * - Security headers
 * - Optional authentication requirement
 * - Response compression hints
 * - Endpoint documentation via OPTIONS
 */
class WP_Headless_API_Enhancer {

    private array $settings;

    public function __construct( array $settings ) {
        $this->settings = $settings;
    }

    public function init(): void {
        // CORS headers (must run early)
        add_action( 'rest_api_init', [ $this, 'setup_cors' ], 5 );
        add_filter( 'rest_pre_serve_request', [ $this, 'handle_cors_preflight' ], 5, 4 );

        // Security headers on REST responses
        add_action( 'rest_api_init', [ $this, 'add_security_headers' ] );

        // Rate limiting
        if ( ! empty( $this->settings['api_rate_limit'] ) ) {
            add_filter( 'rest_pre_dispatch', [ $this, 'check_rate_limit' ], 10, 3 );
        }

        // Require auth for write endpoints (optional)
        if ( ! empty( $this->settings['disable_rest_open'] ) ) {
            add_filter( 'rest_authentication_errors', [ $this, 'require_authentication' ] );
        }

        // Enhance REST responses with headless-specific metadata
        add_filter( 'rest_post_dispatch', [ $this, 'enrich_response' ], 10, 3 );

        // Register plugin audit endpoint
        add_action( 'rest_api_init', [ $this, 'register_audit_endpoints' ] );

        // Suppress REST errors leaking internals
        add_filter( 'rest_request_before_callbacks', [ $this, 'sanitize_error_responses' ], 10, 3 );
    }

    // ── CORS ───────────────────────────────────────────────────────────────────

    public function setup_cors(): void {
        remove_filter( 'rest_pre_serve_request', 'rest_send_cors_headers' );
        add_filter( 'rest_pre_serve_request', [ $this, 'send_cors_headers' ], 10, 4 );
    }

    public function send_cors_headers( $served, $result, $request, $server ) {
        $origin          = $_SERVER['HTTP_ORIGIN'] ?? '';
        $allowed_origins = $this->get_allowed_origins();

        if ( in_array( $origin, $allowed_origins, true ) || in_array( '*', $allowed_origins, true ) ) {
            $allow_origin = in_array( '*', $allowed_origins, true ) ? '*' : $origin;
            header( "Access-Control-Allow-Origin: $allow_origin" );
            header( 'Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS' );
            header( 'Access-Control-Allow-Headers: Authorization, Content-Type, X-WP-Nonce, X-Headless-Key' );
            header( 'Access-Control-Expose-Headers: X-WP-Total, X-WP-TotalPages, X-RateLimit-Remaining' );
            header( 'Access-Control-Max-Age: 86400' );
            if ( $origin !== '*' ) {
                header( 'Vary: Origin' );
            }
        }

        return $served;
    }

    public function handle_cors_preflight( $served, $result, $request, $server ) {
        if ( 'OPTIONS' === $_SERVER['REQUEST_METHOD'] ) {
            $this->send_cors_headers( $served, $result, $request, $server );
            header( 'Content-Length: 0' );
            status_header( 204 );
            exit;
        }
        return $served;
    }

    private function get_allowed_origins(): array {
        $raw = $this->settings['cors_origins'] ?? '';
        if ( empty( trim( $raw ) ) ) {
            return [ '*' ];
        }
        return array_map( 'trim', explode( "\n", $raw ) );
    }

    // ── Security Headers ───────────────────────────────────────────────────────

    public function add_security_headers(): void {
        add_filter( 'rest_pre_serve_request', function ( $served ) {
            header( 'X-Content-Type-Options: nosniff' );
            header( 'X-Frame-Options: DENY' );
            header( 'X-XSS-Protection: 1; mode=block' );
            header( 'Referrer-Policy: strict-origin-when-cross-origin' );
            header( 'Permissions-Policy: geolocation=(), camera=(), microphone=()' );
            header( 'Cache-Control: no-store, no-cache, must-revalidate' );
            return $served;
        }, 15 );
    }

    // ── Rate Limiting ──────────────────────────────────────────────────────────

    public function check_rate_limit( $result, $server, $request ) {
        if ( ! is_null( $result ) ) {
            return $result;
        }

        global $wpdb;

        $ip       = $this->get_client_ip();
        $endpoint = $request->get_route();
        $max      = (int) ( $this->settings['api_rate_limit_max'] ?? 100 );
        $window   = 'INTERVAL 1 HOUR';

        // Authenticated users get 5x the limit
        if ( is_user_logged_in() ) {
            $max *= 5;
        }

        $table = $wpdb->prefix . 'headless_ratelimit';

        // Upsert hit count
        $wpdb->query( $wpdb->prepare(
            "INSERT INTO $table (ip, endpoint, hits, window_start)
             VALUES (%s, %s, 1, NOW())
             ON DUPLICATE KEY UPDATE
               hits = IF(window_start < DATE_SUB(NOW(), $window), 1, hits + 1),
               window_start = IF(window_start < DATE_SUB(NOW(), $window), NOW(), window_start)",
            $ip, $endpoint
        ) );

        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT hits, window_start FROM $table WHERE ip = %s AND endpoint = %s",
            $ip, $endpoint
        ) );

        $hits      = (int) ( $row->hits ?? 1 );
        $remaining = max( 0, $max - $hits );

        header( "X-RateLimit-Limit: $max" );
        header( "X-RateLimit-Remaining: $remaining" );
        header( 'X-RateLimit-Window: 3600' );

        if ( $hits > $max ) {
            return new WP_Error(
                'rate_limit_exceeded',
                __( 'Too many requests. Please slow down.', 'wp-headless-mode' ),
                [ 'status' => 429 ]
            );
        }

        return $result;
    }

    private function get_client_ip(): string {
        foreach ( [ 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ] as $key ) {
            if ( ! empty( $_SERVER[ $key ] ) ) {
                return trim( explode( ',', $_SERVER[ $key ] )[0] );
            }
        }
        return '0.0.0.0';
    }

    // ── Auth Enforcement ───────────────────────────────────────────────────────

    public function require_authentication( $errors ) {
        if ( ! empty( $errors ) ) {
            return $errors;
        }
        if ( ! is_user_logged_in() ) {
            return new WP_Error(
                'rest_not_logged_in',
                __( 'Authentication required.', 'wp-headless-mode' ),
                [ 'status' => 401 ]
            );
        }
        return $errors;
    }

    // ── Response Enrichment ────────────────────────────────────────────────────

    public function enrich_response( $response, $server, $request ) {
        if ( ! ( $response instanceof WP_REST_Response ) ) {
            return $response;
        }
        $response->header( 'X-Headless-Mode', 'true' );
        $response->header( 'X-Response-Time', round( ( microtime( true ) - $_SERVER['REQUEST_TIME_FLOAT'] ) * 1000 ) . 'ms' );
        return $response;
    }

    // ── Audit Endpoints ────────────────────────────────────────────────────────

    public function register_audit_endpoints(): void {
        register_rest_route( 'headless/v1', '/plugins', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'endpoint_plugin_audit' ],
            'permission_callback' => fn() => current_user_can( 'manage_options' ),
            'args'                => [
                'classification' => [
                    'type' => 'string',
                    'enum' => [ 'headless-ready', 'admin-only', 'api-aware', 'frontend', 'unknown' ],
                ],
                'active_only' => [ 'type' => 'boolean', 'default' => false ],
            ],
        ] );

        register_rest_route( 'headless/v1', '/plugins/(?P<slug>[a-z0-9\-]+)/classify', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'endpoint_set_classification' ],
            'permission_callback' => fn() => current_user_can( 'manage_options' ),
            'args'                => [
                'classification' => [
                    'required' => true,
                    'type'     => 'string',
                    'enum'     => [ 'headless-ready', 'admin-only', 'api-aware', 'frontend', 'unknown' ],
                ],
            ],
        ] );

        register_rest_route( 'headless/v1', '/health', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'endpoint_health' ],
            'permission_callback' => '__return_true',
        ] );

        register_rest_route( 'headless/v1', '/settings', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [ $this, 'endpoint_get_settings' ],
                'permission_callback' => fn() => current_user_can( 'manage_options' ),
            ],
            [
                'methods'             => WP_REST_Server::EDITABLE,
                'callback'            => [ $this, 'endpoint_update_settings' ],
                'permission_callback' => fn() => current_user_can( 'manage_options' ),
            ],
        ] );
    }

    public function endpoint_plugin_audit( WP_REST_Request $request ): WP_REST_Response {
        $plugins = WP_Headless_Plugin_Classifier::classify_all();

        if ( $filter = $request->get_param( 'classification' ) ) {
            $plugins = array_filter( $plugins, fn( $p ) => $p['classification'] === $filter );
        }
        if ( $request->get_param( 'active_only' ) ) {
            $plugins = array_filter( $plugins, fn( $p ) => $p['active'] );
        }

        $summary = [
            'headless-ready' => 0, 'admin-only' => 0,
            'api-aware' => 0, 'frontend' => 0, 'unknown' => 0,
        ];
        foreach ( $plugins as $p ) {
            $summary[ $p['classification'] ] = ( $summary[ $p['classification'] ] ?? 0 ) + 1;
        }

        return new WP_REST_Response( [
            'summary' => $summary,
            'plugins' => array_values( $plugins ),
        ], 200 );
    }

    public function endpoint_set_classification( WP_REST_Request $request ): WP_REST_Response {
        $slug           = $request->get_param( 'slug' );
        $classification = $request->get_param( 'classification' );
        WP_Headless_Plugin_Classifier::set_override( $slug, $classification );
        return new WP_REST_Response( [ 'success' => true, 'slug' => $slug, 'classification' => $classification ] );
    }

    public function endpoint_health( WP_REST_Request $request ): WP_REST_Response {
        global $wpdb;
        $db_ok = (bool) $wpdb->get_var( 'SELECT 1' );
        return new WP_REST_Response( [
            'status'      => $db_ok ? 'ok' : 'degraded',
            'headless'    => true,
            'version'     => WP_HEADLESS_VERSION,
            'wp_version'  => get_bloginfo( 'version' ),
            'php_version' => PHP_VERSION,
            'timestamp'   => gmdate( 'c' ),
        ], $db_ok ? 200 : 503 );
    }

    public function endpoint_get_settings( WP_REST_Request $request ): WP_REST_Response {
        $settings = get_option( WP_HEADLESS_OPTIONS_KEY, [] );
        unset( $settings['direct_api_secret'] ); // Never expose secret via API
        return new WP_REST_Response( $settings );
    }

    public function endpoint_update_settings( WP_REST_Request $request ): WP_REST_Response {
        $body     = $request->get_json_params();
        $settings = get_option( WP_HEADLESS_OPTIONS_KEY, [] );
        // Whitelist updatable settings
        $allowed = [
            'disable_emojis', 'disable_embeds', 'disable_xmlrpc',
            'disable_wlwmanifest', 'disable_rsd', 'api_rate_limit',
            'api_rate_limit_max', 'cors_origins', 'disable_rest_open',
        ];
        foreach ( $allowed as $key ) {
            if ( array_key_exists( $key, $body ) ) {
                $settings[ $key ] = $body[ $key ];
            }
        }
        update_option( WP_HEADLESS_OPTIONS_KEY, $settings );
        return new WP_REST_Response( [ 'success' => true ] );
    }

    public function sanitize_error_responses( $response, $handler, $request ) {
        return $response; // Can intercept WP_Error and strip stack traces in future
    }
}
