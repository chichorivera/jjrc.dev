<?php
defined( 'ABSPATH' ) || exit;

/**
 * WP_Headless_Optimizer
 *
 * Performance optimizations for headless WordPress:
 * - Prevent frontend plugins from loading their assets
 * - Disable unnecessary DB queries
 * - Skip theme initialization for REST/API requests
 * - Reduce autoloaded options
 */
class WP_Headless_Optimizer {

    private array $settings;

    // Frontend-only plugins that should not load on API requests
    private const FRONTEND_ONLY_PLUGINS = [
        'elementor/elementor.php',
        'elementor-pro/elementor-pro.php',
        'beaver-builder-plugin/fl-builder.php',
        'wp-super-cache/wp-cache.php',
        'w3-total-cache/w3-total-cache.php',
        'wp-rocket/wp-rocket.php',
        'litespeed-cache/litespeed-cache.php',
        'autoptimize/autoptimize.php',
        'wp-fastest-cache/wpFastestCache.php',
        'jetpack/jetpack.php',
    ];

    public function __construct( array $settings ) {
        $this->settings = $settings;
    }

    public function init(): void {
        if ( empty( $this->settings['headless_mode'] ) ) {
            return;
        }

        // Early: before plugins load their hooks
        add_filter( 'option_active_plugins', [ $this, 'filter_active_plugins' ], 1 );

        // Skip heartbeat on REST requests (saves DB load)
        add_action( 'init', [ $this, 'maybe_disable_heartbeat' ] );

        // Remove query-heavy features on API requests
        if ( $this->is_rest_request() ) {
            add_action( 'after_setup_theme', [ $this, 'disable_theme_support_for_api' ], 1 );
            add_filter( 'show_admin_bar',    '__return_false' );
            add_action( 'wp',                [ $this, 'remove_frontend_actions_on_api' ] );
        }

        // Cleanup autoloaded options (one-time on settings save)
        add_action( 'wp_headless_optimize_autoload', [ $this, 'optimize_autoloaded_options' ] );

        // Scheduled cache cleanup
        if ( ! wp_next_scheduled( 'wp_headless_cache_cleanup' ) ) {
            wp_schedule_event( time(), 'hourly', 'wp_headless_cache_cleanup' );
        }
        add_action( 'wp_headless_cache_cleanup', [ $this, 'cleanup_cache' ] );
    }

    /**
     * On REST API requests, prevent known frontend-only plugins from loading.
     * This saves significant memory and CPU on API calls.
     */
    public function filter_active_plugins( array $plugins ): array {
        if ( ! $this->is_rest_request() ) {
            return $plugins;
        }

        $manual_overrides = (array) get_option( 'wp_headless_plugin_overrides', [] );
        $filtered         = [];

        foreach ( $plugins as $plugin_file ) {
            $slug = explode( '/', $plugin_file )[0] ?? $plugin_file;

            // Manual override: if marked as frontend, skip on REST
            if ( isset( $manual_overrides[ $slug ] ) && $manual_overrides[ $slug ] === 'frontend' ) {
                continue;
            }

            // Known frontend-only list
            if ( in_array( $plugin_file, self::FRONTEND_ONLY_PLUGINS, true ) ) {
                continue;
            }

            $filtered[] = $plugin_file;
        }

        return $filtered;
    }

    public function maybe_disable_heartbeat(): void {
        if ( $this->is_rest_request() || ( ! is_admin() && $this->is_non_admin_page() ) ) {
            wp_deregister_script( 'heartbeat' );
        }
    }

    public function disable_theme_support_for_api(): void {
        // Don't load theme features that add weight on API responses
        remove_theme_support( 'automatic-feed-links' );
        remove_theme_support( 'custom-background' );
        remove_theme_support( 'custom-header' );
        remove_theme_support( 'widgets' );
        remove_theme_support( 'menus' );
    }

    public function remove_frontend_actions_on_api(): void {
        // Remove frontend hooks that might run during REST
        remove_action( 'wp_head',   'wp_enqueue_scripts', 1 );
        remove_action( 'wp_footer', 'wp_print_footer_scripts', 20 );
    }

    /**
     * Optimize autoloaded wp_options.
     * WP loads ALL autoloaded options on every request — a huge overhead.
     * This sets non-critical options to NOT autoload.
     */
    public function optimize_autoloaded_options(): void {
        global $wpdb;

        $non_critical_patterns = [
            'widget_%',
            'sidebars_widgets',
            '%_transient_%',
            'elementor%',
            'fl_%',
            'theme_mods_%',
        ];

        foreach ( $non_critical_patterns as $pattern ) {
            $wpdb->query( $wpdb->prepare(
                "UPDATE {$wpdb->options} SET autoload = 'no' WHERE option_name LIKE %s AND autoload = 'yes'",
                $pattern
            ) );
        }

        wp_cache_delete( 'alloptions', 'options' );
    }

    public function cleanup_cache(): void {
        global $wpdb;
        $wpdb->query( "DELETE FROM {$wpdb->prefix}headless_cache WHERE expires_at < NOW()" );
        $wpdb->query(
            "DELETE FROM {$wpdb->prefix}headless_ratelimit WHERE window_start < DATE_SUB(NOW(), INTERVAL 1 HOUR)"
        );
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    private function is_rest_request(): bool {
        if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
            return true;
        }
        $rest_prefix = trailingslashit( rest_get_url_prefix() );
        return str_contains( $_SERVER['REQUEST_URI'] ?? '', '/' . $rest_prefix );
    }

    private function is_non_admin_page(): bool {
        return ! is_admin();
    }
}
