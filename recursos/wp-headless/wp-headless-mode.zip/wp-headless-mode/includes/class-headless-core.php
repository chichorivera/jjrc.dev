<?php
defined( 'ABSPATH' ) || exit;

/**
 * WP_Headless_Core
 *
 * Handles fundamental headless transformations:
 * - Redirect all frontend requests to 404 or custom page
 * - Block theme loading
 * - Disable unnecessary WP features
 */
class WP_Headless_Core {

    private array $settings;

    public function __construct( array $settings ) {
        $this->settings = $settings;
    }

    public function init(): void {
        if ( empty( $this->settings['headless_mode'] ) ) {
            return;
        }

        // Block frontend theme rendering
        if ( ! empty( $this->settings['disable_themes'] ) ) {
            add_filter( 'template_include',     [ $this, 'block_theme_rendering' ], PHP_INT_MAX );
            add_filter( 'stylesheet',            [ $this, 'use_empty_theme' ] );
            add_filter( 'template',              [ $this, 'use_empty_theme' ] );
            add_action( 'wp_enqueue_scripts',    [ $this, 'dequeue_theme_assets' ], PHP_INT_MAX );
        }

        // Security & noise removal
        if ( ! empty( $this->settings['disable_xmlrpc'] ) ) {
            add_filter( 'xmlrpc_enabled', '__return_false' );
            add_filter( 'wp_xmlrpc_server_class', [ $this, 'disable_xmlrpc_server' ] );
            // Remove xmlrpc link from header
            remove_action( 'wp_head', 'rsd_link' );
        }

        if ( ! empty( $this->settings['disable_embeds'] ) ) {
            add_action( 'init', [ $this, 'disable_embeds' ] );
        }

        if ( ! empty( $this->settings['disable_emojis'] ) ) {
            add_action( 'init', [ $this, 'disable_emojis' ] );
        }

        if ( ! empty( $this->settings['disable_wlwmanifest'] ) ) {
            remove_action( 'wp_head', 'wlwmanifest_link' );
        }

        if ( ! empty( $this->settings['disable_rsd'] ) ) {
            remove_action( 'wp_head', 'rsd_link' );
        }

        // Additional noise
        add_action( 'init', [ $this, 'disable_misc_noise' ] );

        // Add X-Headless header to all responses
        add_action( 'send_headers', [ $this, 'add_headless_headers' ] );
    }

    // ── Theme Blocking ─────────────────────────────────────────────────────────

    /**
     * Replaces any template with a JSON-only 404 response when
     * the request is NOT coming from wp-admin or the REST API.
     */
    public function block_theme_rendering( string $template ): string {
        if ( $this->is_admin_or_api_request() ) {
            return $template;
        }

        // Allow authenticated admin users to preview if needed
        if ( current_user_can( 'manage_options' ) && isset( $_GET['preview_theme'] ) ) {
            return $template;
        }

        // Return a minimal PHP template that outputs JSON
        return WP_HEADLESS_DIR . 'includes/templates/headless-frontend.php';
    }

    public function use_empty_theme(): string {
        // Return current theme to keep admin working; frontend blocked via template_include
        return get_option( 'template' );
    }

    public function dequeue_theme_assets(): void {
        if ( $this->is_admin_or_api_request() ) {
            return;
        }
        global $wp_styles, $wp_scripts;
        $wp_styles  = new WP_Styles();
        $wp_scripts = new WP_Scripts();
    }

    public function disable_xmlrpc_server(): string {
        return 'WP_Headless_XMLRPC_Stub';
    }

    // ── Feature Disablers ──────────────────────────────────────────────────────

    public function disable_embeds(): void {
        remove_action( 'rest_api_init',        'wp_oembed_register_route' );
        remove_filter( 'oembed_dataparse',     'wp_filter_oembed_result' );
        remove_action( 'wp_head',              'wp_oembed_add_discovery_links' );
        remove_action( 'wp_head',              'wp_oembed_add_host_js' );
        remove_action( 'rest_api_init',        'wp_oembed_register_route' );
        remove_filter( 'pre_oembed_result',    'wp_filter_pre_oembed_result' );
        add_filter( 'embed_oembed_discover',   '__return_false' );
        add_filter( 'rewrite_rules_array',     [ $this, 'remove_embed_rewrite_rules' ] );
    }

    public function remove_embed_rewrite_rules( array $rules ): array {
        foreach ( $rules as $rule => $rewrite ) {
            if ( str_contains( $rewrite, 'embed=true' ) ) {
                unset( $rules[ $rule ] );
            }
        }
        return $rules;
    }

    public function disable_emojis(): void {
        remove_action( 'wp_head',             'print_emoji_detection_script', 7 );
        remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
        remove_action( 'wp_print_styles',     'print_emoji_styles' );
        remove_action( 'admin_print_styles',  'print_emoji_styles' );
        remove_filter( 'the_content_feed',    'wp_staticize_emoji' );
        remove_filter( 'comment_text_rss',    'wp_staticize_emoji' );
        remove_filter( 'wp_mail',             'wp_staticize_emoji_for_email' );
        add_filter( 'tiny_mce_plugins',       [ $this, 'remove_tinymce_emojis' ] );
        add_filter( 'wp_resource_hints',      [ $this, 'remove_emoji_dns_prefetch' ], 10, 2 );
    }

    public function remove_tinymce_emojis( array $plugins ): array {
        return array_diff( $plugins, [ 'wpemoji' ] );
    }

    public function remove_emoji_dns_prefetch( array $urls, string $relation_type ): array {
        if ( 'dns-prefetch' === $relation_type ) {
            $urls = array_filter( $urls, fn( $url ) => ! str_contains( $url, 's.w.org' ) );
        }
        return $urls;
    }

    public function disable_misc_noise(): void {
        // Generator meta tag (security)
        remove_action( 'wp_head', 'wp_generator' );
        // Shortlink
        remove_action( 'wp_head', 'wp_shortlink_wp_head' );
        // Adjacent posts links
        remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head' );
        // Feed links
        remove_action( 'wp_head', 'feed_links',       2 );
        remove_action( 'wp_head', 'feed_links_extra', 3 );
        // REST API expose in header
        remove_action( 'wp_head', 'rest_output_link_wp_head' );
        remove_action( 'template_redirect', 'rest_output_link_header', 11 );
        // oEmbed
        remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
        // DNS prefetch
        add_filter( 'wp_resource_hints', '__return_empty_array' );
    }

    // ── Headers ────────────────────────────────────────────────────────────────

    public function add_headless_headers(): void {
        header( 'X-WP-Headless: 1' );
        header( 'X-WP-Headless-Version: ' . WP_HEADLESS_VERSION );
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    private function is_admin_or_api_request(): bool {
        if ( is_admin() ) {
            return true;
        }
        // Check if this is a REST API request
        $rest_prefix = trailingslashit( rest_get_url_prefix() );
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        if ( str_contains( $request_uri, '/' . $rest_prefix ) ) {
            return true;
        }
        return defined( 'REST_REQUEST' ) && REST_REQUEST;
    }
}

// Minimal stub to fully disable XML-RPC
class WP_Headless_XMLRPC_Stub {
    public function __construct() {
        status_header( 403 );
        header( 'Content-Type: application/json' );
        echo json_encode( [ 'error' => 'XML-RPC disabled in headless mode.' ] );
        exit;
    }
}
