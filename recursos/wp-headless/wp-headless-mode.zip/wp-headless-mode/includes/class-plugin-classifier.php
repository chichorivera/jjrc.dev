<?php
defined( 'ABSPATH' ) || exit;

/**
 * WP_Headless_Plugin_Classifier
 *
 * Reads plugin metadata + a community/manual taxonomy to label every
 * installed plugin as one of:
 *   - admin-only      → Safe in headless, never touches frontend
 *   - frontend        → Renders HTML, NOT headless-compatible
 *   - api-aware       → Has REST/GraphQL support, headless-compatible
 *   - headless-ready  → Designed for headless (e.g. WPGraphQL, ACF)
 *   - unknown         → Needs manual review
 */
class WP_Headless_Plugin_Classifier {

    /**
     * Known plugin slugs → classification.
     * Community-maintained list bundled with the plugin.
     */
    private const KNOWN_CLASSIFICATIONS = [
        // ── Headless-ready ────────────────────────────────────────────────
        'wp-graphql'                     => 'headless-ready',
        'wpgraphql-acf'                  => 'headless-ready',
        'headless-mode'                  => 'headless-ready',
        'wp-gatsby'                      => 'headless-ready',
        'faust'                          => 'headless-ready',
        'wp-rest-api-v2-menus'           => 'headless-ready',
        'jwt-authentication-for-wp-rest-api' => 'headless-ready',
        'application-passwords'          => 'headless-ready',
        'advanced-custom-fields'         => 'headless-ready',    // Has REST API support
        'acf-to-rest-api'                => 'headless-ready',
        'pods'                           => 'headless-ready',

        // ── API-aware (partial headless support) ──────────────────────────
        'woocommerce'                    => 'api-aware',
        'yoast-seo'                      => 'api-aware',         // Exposes meta via REST
        'rank-math'                      => 'api-aware',
        'the-seo-framework'              => 'api-aware',
        'wp-seopress'                    => 'api-aware',
        'contact-form-7'                 => 'api-aware',
        'gravity-forms'                  => 'api-aware',
        'wpforms-lite'                   => 'api-aware',
        'polylang'                       => 'api-aware',
        'wpml'                           => 'api-aware',

        // ── Admin-only (safe in headless) ─────────────────────────────────
        'wordfence'                      => 'admin-only',
        'really-simple-ssl'              => 'admin-only',
        'wp-mail-smtp'                   => 'admin-only',
        'updraftplus'                    => 'admin-only',
        'all-in-one-wp-migration'        => 'admin-only',
        'query-monitor'                  => 'admin-only',
        'user-role-editor'               => 'admin-only',
        'members'                        => 'admin-only',
        'wp-2fa'                         => 'admin-only',
        'antispam-bee'                   => 'admin-only',
        'stream'                         => 'admin-only',
        'wp-crontrol'                    => 'admin-only',
        'wp-migrate-db'                  => 'admin-only',
        'safe-svg'                       => 'admin-only',
        'enable-media-replace'           => 'admin-only',
        'media-library-assistant'        => 'admin-only',
        'capability-manager-enhanced'    => 'admin-only',
        'wp-reset'                       => 'admin-only',

        // ── Frontend (NOT headless-compatible) ────────────────────────────
        'elementor'                      => 'frontend',
        'elementor-pro'                  => 'frontend',
        'beaver-builder-plugin'          => 'frontend',
        'divi-builder'                   => 'frontend',
        'visual-composer'                => 'frontend',
        'wpbakery-page-builder'          => 'frontend',
        'generateblocks'                 => 'frontend',
        'kadence-blocks'                 => 'frontend',
        'ultimate-addons-for-gutenberg'  => 'frontend',
        'jetpack'                        => 'frontend',          // Mostly frontend
        'wp-super-cache'                 => 'frontend',
        'w3-total-cache'                 => 'frontend',
        'wp-rocket'                      => 'frontend',
        'litespeed-cache'                => 'frontend',
        'autoptimize'                    => 'frontend',
        'smush'                          => 'frontend',
        'imagify'                        => 'frontend',
        'wp-fastest-cache'               => 'frontend',
        'mailchimp-for-wp'               => 'frontend',
        'cookie-notice'                  => 'frontend',
        'gdpr-cookie-consent'            => 'frontend',
        'wp-cookie-notice'               => 'frontend',
        'eleganthemes-backup'            => 'frontend',
    ];

    /**
     * Heuristic patterns in plugin headers that hint at category.
     */
    private const FRONTEND_KEYWORDS = [
        'page builder', 'pagebuilder', 'visual editor', 'shortcode',
        'widget', 'theme', 'sidebar', 'gutenberg block', 'block editor',
        'cache', 'minif', 'lazy load', 'cdn', 'cookie', 'gdpr banner',
    ];

    private const ADMIN_KEYWORDS = [
        'backup', 'security', 'firewall', 'migration', 'cron', 'log',
        'audit', 'smtp', 'mail', 'role', 'permission', 'capability',
        '2fa', 'two factor', 'two-factor',
    ];

    private const HEADLESS_KEYWORDS = [
        'rest api', 'graphql', 'headless', 'json api', 'webhook',
        'api endpoint', 'jwt', 'application password',
    ];

    // ── Public API ─────────────────────────────────────────────────────────────

    /**
     * Returns classification data for all installed plugins.
     *
     * @return array<string, array{
     *   name: string,
     *   slug: string,
     *   version: string,
     *   description: string,
     *   classification: string,
     *   headless_impact: string,
     *   recommendation: string,
     *   active: bool,
     *   manual_override: string|null,
     * }>
     */
    public static function classify_all(): array {
        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $all_plugins      = get_plugins();
        $active_plugins   = (array) get_option( 'active_plugins', [] );
        $manual_overrides = (array) get_option( 'wp_headless_plugin_overrides', [] );
        $results          = [];

        foreach ( $all_plugins as $plugin_file => $plugin_data ) {
            $slug           = self::extract_slug( $plugin_file );
            $classification = $manual_overrides[ $slug ] ?? self::classify_plugin( $slug, $plugin_data );

            $results[ $slug ] = [
                'name'            => $plugin_data['Name'],
                'slug'            => $slug,
                'version'         => $plugin_data['Version'],
                'description'     => wp_strip_all_tags( $plugin_data['Description'] ),
                'author'          => $plugin_data['AuthorName'] ?? $plugin_data['Author'],
                'classification'  => $classification,
                'headless_impact' => self::get_impact( $classification ),
                'recommendation'  => self::get_recommendation( $classification ),
                'active'          => in_array( $plugin_file, $active_plugins, true ),
                'plugin_file'     => $plugin_file,
                'manual_override' => $manual_overrides[ $slug ] ?? null,
            ];
        }

        // Sort: frontend first (most critical), then unknown, then rest
        uasort( $results, function ( $a, $b ) {
            $priority = [ 'frontend' => 0, 'unknown' => 1, 'api-aware' => 2, 'admin-only' => 3, 'headless-ready' => 4 ];
            return ( $priority[ $a['classification'] ] ?? 1 ) <=> ( $priority[ $b['classification'] ] ?? 1 );
        } );

        return $results;
    }

    /**
     * Save a manual override for a plugin slug.
     */
    public static function set_override( string $slug, string $classification ): void {
        $allowed = [ 'admin-only', 'frontend', 'api-aware', 'headless-ready', 'unknown' ];
        if ( ! in_array( $classification, $allowed, true ) ) {
            return;
        }
        $overrides          = (array) get_option( 'wp_headless_plugin_overrides', [] );
        $overrides[ $slug ] = $classification;
        update_option( 'wp_headless_plugin_overrides', $overrides );
    }

    public static function remove_override( string $slug ): void {
        $overrides = (array) get_option( 'wp_headless_plugin_overrides', [] );
        unset( $overrides[ $slug ] );
        update_option( 'wp_headless_plugin_overrides', $overrides );
    }

    // ── Private Helpers ────────────────────────────────────────────────────────

    private static function classify_plugin( string $slug, array $plugin_data ): string {
        // 1. Known list takes priority
        if ( isset( self::KNOWN_CLASSIFICATIONS[ $slug ] ) ) {
            return self::KNOWN_CLASSIFICATIONS[ $slug ];
        }

        // 2. Heuristic: scan Name + Description
        $haystack = strtolower( $plugin_data['Name'] . ' ' . $plugin_data['Description'] );

        if ( self::matches_any( $haystack, self::HEADLESS_KEYWORDS ) ) {
            return 'headless-ready';
        }
        if ( self::matches_any( $haystack, self::ADMIN_KEYWORDS ) ) {
            return 'admin-only';
        }
        if ( self::matches_any( $haystack, self::FRONTEND_KEYWORDS ) ) {
            return 'frontend';
        }

        return 'unknown';
    }

    private static function matches_any( string $haystack, array $needles ): bool {
        foreach ( $needles as $needle ) {
            if ( str_contains( $haystack, $needle ) ) {
                return true;
            }
        }
        return false;
    }

    private static function extract_slug( string $plugin_file ): string {
        // plugin-folder/plugin-file.php → plugin-folder
        $parts = explode( '/', $plugin_file );
        return count( $parts ) > 1 ? $parts[0] : pathinfo( $plugin_file, PATHINFO_FILENAME );
    }

    private static function get_impact( string $classification ): string {
        return match ( $classification ) {
            'headless-ready' => 'none',
            'admin-only'     => 'none',
            'api-aware'      => 'low',
            'unknown'        => 'medium',
            'frontend'       => 'high',
            default          => 'unknown',
        };
    }

    private static function get_recommendation( string $classification ): string {
        return match ( $classification ) {
            'headless-ready' => 'Compatible con headless. Sin acción requerida.',
            'admin-only'     => 'Solo actúa en el admin. Seguro en headless.',
            'api-aware'      => 'Tiene soporte REST pero también puede cargar assets en el frontend. Revisar configuración.',
            'unknown'        => 'Sin clasificación conocida. Auditar manualmente.',
            'frontend'       => '⚠️ Plugin de frontend. No está pensado para headless. Evaluar desactivar o reemplazar.',
            default          => 'Sin datos.',
        };
    }
}
