<?php
// This theme is a placeholder for headless WordPress.
// The frontend is served by a separate application via REST API.
// See: WP Headless Mode plugin.
