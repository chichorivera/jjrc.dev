<?php
/**
 * Plugin Name:     WP Headless Mode
 * Plugin URI:      https://github.com/your-org/wp-headless-mode
 * Description:     Optimiza WordPress para arquitecturas headless: deshabilita themes, clasifica plugins, robustece y protege la REST API nativa.
 * Version:         1.3.1
 * Author:          Javier Rivera + Claude + GitHub Copilot
 * Author URI:      https://jjrc.dev
 * License:         GPL-2.0-or-later
 * Text Domain:     wp-headless-mode
 * Requires PHP:    8.0
 * Requires at least: 6.0
 */

defined( 'ABSPATH' ) || exit;

define( 'WP_HEADLESS_VERSION', '1.3.1' );
define( 'WP_HEADLESS_DIR', plugin_dir_path( __FILE__ ) );
define( 'WP_HEADLESS_URL', plugin_dir_url( __FILE__ ) );
define( 'WP_HEADLESS_OPTIONS_KEY', 'wp_headless_settings' );

// ── Autoload ──────────────────────────────────────────────────────────────────
require_once WP_HEADLESS_DIR . 'includes/class-headless-core.php';
require_once WP_HEADLESS_DIR . 'includes/class-headless-optimizer.php';
require_once WP_HEADLESS_DIR . 'includes/class-plugin-classifier.php';
require_once WP_HEADLESS_DIR . 'includes/class-api-enhancer.php';
require_once WP_HEADLESS_DIR . 'admin/class-headless-admin.php';

// ── Bootstrap ─────────────────────────────────────────────────────────────────
function wp_headless_mode_init(): void {
    $settings = get_option( WP_HEADLESS_OPTIONS_KEY, [] );

    $core      = new WP_Headless_Core( $settings );
    $optimizer = new WP_Headless_Optimizer( $settings );
    $api       = new WP_Headless_API_Enhancer( $settings );

    $core->init();
    $optimizer->init();
    $api->init();

    if ( is_admin() ) {
        $admin = new WP_Headless_Admin( $settings );
        $admin->init();
    }
}
add_action( 'plugins_loaded', 'wp_headless_mode_init' );

// ── Activation / Deactivation ─────────────────────────────────────────────────
register_activation_hook( __FILE__, function (): void {
    if ( ! get_option( WP_HEADLESS_OPTIONS_KEY ) ) {
        add_option( WP_HEADLESS_OPTIONS_KEY, [
            'headless_mode'       => true,
            'disable_themes'      => true,
            'disable_xmlrpc'      => true,
            'disable_embeds'      => true,
            'disable_emojis'      => true,
            'disable_wlwmanifest' => true,
            'disable_rsd'         => true,
            'disable_rest_open'   => false,
            'api_rate_limit'      => true,
            'api_rate_limit_max'  => 100,
            'jwt_auth'            => false,
            'cors_origins'        => '',
            'plugin_audit'        => true,
        ] );
    }
    // Rate-limit table for REST API
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $sql2 = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}headless_ratelimit (
        ip          VARCHAR(45)  NOT NULL,
        endpoint    VARCHAR(255) NOT NULL,
        hits        INT          NOT NULL DEFAULT 0,
        window_start DATETIME   NOT NULL,
        PRIMARY KEY (ip, endpoint),
        INDEX idx_window (window_start)
    ) $charset;";
    dbDelta( $sql2 );

} );

register_deactivation_hook( __FILE__, function (): void {
    wp_clear_scheduled_hook( 'wp_headless_cache_cleanup' );
} );
