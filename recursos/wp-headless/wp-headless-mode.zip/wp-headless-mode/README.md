# WP Headless Mode

Plugin de WordPress para optimizar instalaciones en modo **headless** (CMS desacoplado).

---

## ¿Qué hace?

### 🚀 Modo Headless Core
- **Bloquea el frontend de WordPress**: toda URL no-admin y no-API devuelve JSON 404 en vez de HTML
- Elimina la carga del theme en requests de API (ahorra ~8-15 MB RAM)
- Desactiva XML-RPC, embeds, emojis, wlwmanifest, RSD y otros vestigios

### 🔍 Auditoría de Plugins
Clasifica automáticamente cada plugin instalado como:

| Clasificación | Descripción |
|---|---|
| 🟢 **Headless Ready** | Diseñado para headless (WPGraphQL, ACF, JWT Auth...) |
| 🔵 **Solo Admin** | Solo actúa en wp-admin. Seguro. (Wordfence, Updraft...) |
| 🟡 **API Aware** | Tiene endpoints REST pero también carga assets en el frontend |
| 🔴 **Frontend Only** | Renderizador HTML. No compatible con headless (Elementor, caches...) |
| ⚪ **Sin clasificar** | Necesita revisión manual |

La clasificación usa una lista curada de 50+ plugins conocidos + heurísticas de texto.  
Puedes sobrescribir la clasificación manualmente desde el panel.

### 🔐 REST API Endurecida
- **CORS**: configuración granular de orígenes permitidos
- **Rate limiting**: por IP + endpoint, con headers `X-RateLimit-*`
- **Headers de seguridad**: `X-Content-Type-Options`, `X-Frame-Options`, `CSP`, etc.
- **Auth opcional**: puede requerir autenticación en todos los endpoints
- **Tiempo de respuesta**: header `X-Response-Time` en cada respuesta

### 🗄 Optimización de Autoload
WordPress carga **todas** las opciones con `autoload=yes` en cada request.  
El plugin puede marcar las no críticas (widgets, sidebars, cache de tema, etc.) como `autoload=no`,  
reduciendo el tamaño del payload de options en cada request de API.

---

## Instalación

1. Copiar la carpeta `wp-headless-mode` a `/wp-content/plugins/`
2. Activar desde `Plugins → Plugins instalados`
3. Ir a `Headless Mode → Configuración` y activar el modo
4. Configurar los orígenes CORS permitidos con la URL de tu frontend

## Requisitos

- WordPress 6.0+
- PHP 8.0+
- MySQL 5.7+ o MariaDB 10.3+

---

## Endpoints de administración

| Endpoint | Descripción |
|---|---|
| `GET /headless/v1/plugins` | Lista de plugins con clasificación |
| `POST /headless/v1/plugins/{slug}/classify` | Sobrescribir clasificación |
| `GET /headless/v1/health` | Health check (público) |
| `GET /headless/v1/settings` | Configuración actual |
| `PATCH /headless/v1/settings` | Actualizar configuración |

Todos requieren `manage_options` (admin).

---

## Caveats

### Lo que un plugin NO puede eliminar
El bootstrap de WordPress siempre carga ~200 archivos PHP más la query de options.  
Para un headless más radical considera:
- **Bedrock** (Roots.io) para una estructura más limpia
- Un proxy Nginx que cachee respuestas de la REST API
- **Redis Object Cache** para cachear el bootstrap de WP

### Plugins marcados como "frontend" que desactivas
Si un plugin de frontend (ej: Elementor) está activo y lo desactivas en REST,  
verifica que no registre Custom Post Types o meta fields necesarios para tu API.  
La desactivación en REST es selectiva — el plugin sigue activo en admin.

---

## Estructura del plugin

```
wp-headless-mode/
├── wp-headless-mode.php          ← Entry point
├── includes/
│   ├── class-headless-core.php       ← Bloqueo de themes, features
│   ├── class-headless-optimizer.php  ← Optimización de carga
│   ├── class-plugin-classifier.php   ← Taxonomía de plugins
│   ├── class-api-enhancer.php        ← CORS, rate limit, headers
│   └── templates/
│       └── headless-frontend.php     ← Template JSON para frontend
├── admin/
│   ├── class-headless-admin.php      ← Admin menu + AJAX
│   └── views/
│       ├── dashboard.php
│       ├── plugins.php
│       ├── settings.php
│       ├── themes.php
│       └── about.php
└── assets/
    ├── admin.css
    └── admin.js
```

## Licencia

GPL-2.0-or-later
