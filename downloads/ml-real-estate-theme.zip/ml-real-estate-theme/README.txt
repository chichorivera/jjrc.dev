ML Real Estate Theme for WordPress
Version: 0.1.0
Author: Javier Rivera

Starter theme prepared for listings and MercadoLibre integration workflows.
