BSale WordPress Integration Plugin
Version: 0.1.0
Author: Javier Rivera

This package is a base release for BSale integration with WordPress.

Suggested structure:
- Connector for BSale API
- Product sync jobs
- Stock update hooks
- Logging and retry strategy
