<?php
/**
 * Plugin Name: BSale WordPress Integration
 * Description: Base plugin for BSale integration.
 * Version: 0.1.0
 * Author: Javier Rivera
 */

if (!defined('ABSPATH')) {
    exit;
}
